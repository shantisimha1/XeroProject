import org.openqa.selenium.By;

import org.openqa.selenium.WebDriver;

import org.openqa.selenium.chrome.ChromeDriver;




public class TestCase {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir")+"/chromedriver");
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.xero.com");
		Thread.sleep(5000);
		driver.findElement(By.xpath("/html/body/div[6]/header/nav/div[2]/div/div[1]/div/div/ul/li[2]/a")).click();
		Thread.sleep(5000);
		driver.findElement(By.id("email")).sendKeys("shantisimha@gmail.com");
		
		driver.findElement(By.id("password")).sendKeys("Clemson1!");
		driver.findElement(By.id("submitButton")).click();
		Thread.sleep(5000);
		driver.findElement(By.id("Accounts")).click();
		Thread.sleep(5000);
		driver.findElement(By.xpath("//*[@id=\"xero-nav\"]/div[2]/div[2]/div[1]/ul/li[2]/ul/li[1]/a")).click();
		
		
		Thread.sleep(5000);
		driver.findElement(By.xpath("//*[@id=\"ext-gen60\"]")).click();
		Thread.sleep(5000);
		
		driver.findElement(By.id("xui-searchfield-1018-inputEl")).sendKeys("ANZ (NZ)");
		Thread.sleep(5000);
		driver.findElement(By.xpath("//*[@id=\"component-1026\"]/a")).click();
		driver.findElement(By.id("accountname-1037-inputEl")).sendKeys("Test Account");
		Thread.sleep(5000);
		
		driver.findElement(By.cssSelector("input[placeholder='Please select one']")).click();

		driver.findElement(By.xpath("//li[text()='Other']")).click();
		
		
        Thread.sleep(2000);

		driver.findElement(By.cssSelector("div[id*='accountDetailGeneric'] div[data-ref='outerCt'] div[role='presentation']>div[id*='accountnumber']")).click();
		
		Thread.sleep(3000);
		
		driver.findElement(By.cssSelector("div[id*='accountDetailGeneric'] div[data-ref='outerCt'] div[role='presentation']>div[id*='accountnumber'] input")).sendKeys("3434343123");
		
		driver.findElement(By.xpath("//span[text()='Save']")).click(); 
		
		System.out.println("Bank Added, Test Case Pass");
		

		
		
		
		
	}

}
